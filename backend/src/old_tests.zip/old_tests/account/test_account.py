# import pytest
#
# from accounts.models import User
#
#
# @pytest.mark.django_db
# def test_register_superuser():
#     user_count_before = User.objects.count()
#     superuser = User.objects.create_superuser(
#         name="admin",
#         email="admin@admin.ru",
#         password="admin"
#     )
#     superuser.save()
#     assert User.objects.count() == user_count_before + 1
#
#
# @pytest.mark.django_db
# def test_register_user():
#     user_count_before = User.objects.count()
#     User.objects.create(
#         name="User User",
#         email="user@user.ru",
#         password="SuperPass"
#     )
#     assert User.objects.count() == user_count_before + 1
#
