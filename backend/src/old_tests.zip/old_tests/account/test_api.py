# import pytest
# import rest_framework_simplejwt.authentication
# from django.contrib.auth.models import AnonymousUser
# from django.test import RequestFactory, TestCase
# from rest_framework.test import force_authenticate
# from rest_framework_simplejwt.serializers import TokenObtainSerializer, \
#     TokenObtainPairSerializer
#
# from accounts.models import User
# from projects.views import ProjectViewSet
# from trash.models import Trash
#
#
# @pytest.mark.django_db
# def test_projects_crud(api_client):
#     api_client = api_client[0]
#     # create
#     response = api_client.post('/v1/projects/', data={'name': 'Test prj'})
#     assert response.status_code == 201
#     data = response.json()
#     pr_id = data['id']
#     # list
#     response = api_client.get(f'/v1/projects/')
#     assert response.status_code == 200
#     data = response.json()
#     assert len(data) == 1
#     # get
#     response = api_client.get(f'/v1/projects/{pr_id}/')
#     data = response.json()
#     assert response.status_code == 200
#     assert data['name'] == 'Test prj'
#     # change
#     test_data = {
#         "name": "Test name",
#         "description": "Test description",
#         "tagColor": "blue",
#         "is_in_trash": True
#     }
#     response = api_client.patch(f'/v1/projects/{pr_id}/',
#                                 data=test_data)
#     data = response.json()
#     assert response.status_code == 200
#
#     for k, v in test_data.items():
#         if k in data:
#             assert v == data[k]
#
#     # delete
#     tr_cnt = Trash.objects.count()
#     response = api_client.delete(f'/v1/projects/{pr_id}/')
#     assert response.status_code == 200
#     assert Trash.objects.count() == tr_cnt + 1
#
#
# # class TestProjectsAPI(TestCase):
# #     def setUp(self):
# #         self.factory = RequestFactory()
# #         kwargs = {'email': 'user@mail.com', 'password': 'top_secret'}
# #         self.user = User.objects.create_user(**kwargs)
# #         self.token = TokenObtainPairSerializer(data=kwargs).get_token(self.user)
# #
# #
# #     def test_project_create(self):
# #         request = self.factory.post('/v1/projects/', data={'name': 'Test prj'})
# #         request.user = self.user
# #         project_count_before = Project.objects.count()
# #         force_authenticate(request, user=request.user, token=self.token)
# #         # request.user = AnonymousUser()
# #         response = ProjectViewSet.as_view({'post': 'create'},
# #                                           basename='project')(request)
# #         self.assertEqual(response.status_code, 201)
# #         project_count_after = Project.objects.count()
# #         self.assertEqual(project_count_before+1, project_count_after)
