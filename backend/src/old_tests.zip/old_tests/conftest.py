from django.test import TestCase

import pytest
from rest_framework.test import APIClient
from rest_framework_simplejwt.tokens import RefreshToken

from accounts.models import User


@pytest.fixture
def api_client():
    user = User.objects.create_user(
        name='Test User', email='test@test.ru', password='SuperTest')
    client = APIClient()
    refresh = RefreshToken.for_user(user)
    client.credentials(HTTP_AUTHORIZATION=f'Bearer {refresh.access_token}')
    return client, user


class ConfTest(TestCase):
    @pytest.mark.django_db
    def create_test_user(self):
        return User.objects.create(
            name='Test User',
            email="test_user@test_user.com",
            password="test_user"
        )
