# import pytest
# from django.db import IntegrityError
# from django.test import TestCase
#
# from projects.models import Project
# from tests.conftest import ConfTest
#
#
# @pytest.mark.django_db
# class ModelTest(TestCase):
#
#     def test_project_model_persists(self):
#         test_user = ConfTest.create_test_user(self)
#         new_project = Project()
#         new_project.name = "New project"
#         new_project.owner = test_user
#         new_project.save()
#         assert new_project.name == "New project"
#         assert Project.objects.count() > 0
#
#     def test_project_not_saved_without_owner(self):
#         new_project = Project()
#         with self.assertRaises(IntegrityError):
#             new_project.save()
