from pprint import pprint

from django.urls import reverse
from rest_framework import status
from rest_framework.test import APITestCase, APIClient

from accounts.models import User
from projects.models import Project


class AccountTests(APITestCase):
    def setUp(self):
        self.client = APIClient()
        self.user = User.objects.create(
            name='Test', email='test@mail.com', password='TestPassword')
        self.client.force_authenticate(user=self.user)
        project = Project.objects.create(name='Test project 1', owner=self.user)
        self.prj_id = project.id

    def test_create_project(self):
        url = reverse('project-list')
        data = {'name': 'Test project', 'owner': self.user.pkid}
        project_count_before = Project.objects.count()
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(Project.objects.count(), project_count_before + 1)

    def test_patch_project(self):
        url = reverse('project-detail', args=[self.prj_id])
        patch_data = {
            'name': 'Test project',
            'description': 'Test project description'
        }
        response = self.client.patch(url, patch_data)
        data = response.data
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(data['name'], patch_data['name'])
        self.assertEqual(data['description'], patch_data['description'])

    def test_project_list_view(self):
        url = reverse('project-list')
        response = self.client.get(url)
        data = response.data
        pprint(data)
        self.assertIn('documents', data)

